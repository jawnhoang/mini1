#include "CsvParser.hpp"
#include <fstream>
#include <sstream>
#include <vector>
#include <filesystem>
#ifdef _OPENMP
  #include <omp.h>
#endif
#include <utility>


using namespace std;

/**
 * Reads csv line by line into memory
 * Invokes num_threads threads to store data
 * 
 * Args: filePath, num_threads
 */
vector<vector<string>> CsvParser::read(const string& filePath, int num_threads) {
    ifstream file(filePath);
    string line;
    vector<string> vectorOfLines;

    while (getline(file, line)) {
        vectorOfLines.push_back(line);
    }

    vector<vector<string>> data (vectorOfLines.size());


    #pragma omp parallel for num_threads(num_threads)
    for (int i = 0; i < vectorOfLines.size(); i++){
        stringstream ss(vectorOfLines[i]);
        
        string cell;
        vector<string> row;

        while (getline(ss, cell, ',')) {
            if (cell.back() == '\r'){
                cell.pop_back();
            }
            row.push_back(cell);
        }

        // Strip UTF-8 BOM from the very first cell of the first row, if present
        if (i == 0 && !row.empty()) {
            const unsigned char BOM0 = 0xEF, BOM1 = 0xBB, BOM2 = 0xBF;
            if (row[0].size() >= 3 &&
                (unsigned char)row[0][0] == BOM0 &&
                (unsigned char)row[0][1] == BOM1 &&
                (unsigned char)row[0][2] == BOM2) {
                row[0].erase(0, 3);
            }
        }

        data[i] = std::move(row);

    }
    return data;



};

/**
 * Gathers all filepaths within a root directory
 * 
 * Args: rootDir
 */
vector<string> CsvParser::getFilePaths(const string& rootDir){
    vector<string> csvFilePaths;
    for (const auto& entry : std::filesystem::recursive_directory_iterator(rootDir)) {
    if (entry.is_regular_file() && entry.path().extension() == ".csv") {
        csvFilePaths.push_back(entry.path().string());
    }
    }
    return csvFilePaths;
};
